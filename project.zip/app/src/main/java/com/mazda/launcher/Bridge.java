package com.mazda.launcher;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Functions the web UI can call as Android.xxx(). All return simple strings/booleans. */
public class Bridge {
    private final Context ctx;

    private static volatile String appsCache = null;

    Bridge(Context c) {
        ctx = c;
        refreshApps();
    }

    private void refreshApps() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                appsCache = buildApps();
            }
        }).start();
    }

    private boolean start(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            ctx.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private List<ResolveInfo> apps() {
        PackageManager pm = ctx.getPackageManager();
        List<ResolveInfo> all = new ArrayList<ResolveInfo>();
        java.util.HashSet<String> seen = new java.util.HashSet<String>();
        String[] cats = new String[]{
                Intent.CATEGORY_LAUNCHER,
                "android.intent.category.LEANBACK_LAUNCHER",
                "android.intent.category.CAR_LAUNCHER"
        };
        for (String c : cats) {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(c);
            List<ResolveInfo> l = pm.queryIntentActivities(i, 0);
            if (l == null) {
                continue;
            }
            for (ResolveInfo ri : l) {
                if (seen.add(ri.activityInfo.packageName + "/" + ri.activityInfo.name)) {
                    all.add(ri);
                }
            }
        }
        return all;
    }

    private String findByLabel(String csv) {
        PackageManager pm = ctx.getPackageManager();
        String[] names = csv.split(",");
        for (ResolveInfo ri : apps()) {
            String label = String.valueOf(ri.loadLabel(pm)).toLowerCase();
            for (String n : names) {
                String t = n.trim().toLowerCase();
                if (t.length() > 0 && label.contains(t)) {
                    return ri.activityInfo.packageName;
                }
            }
        }
        return null;
    }

    /** json: [{"p":"pkg","c":"class","l":"label1,label2"}, ...] - tries each entry until one opens. */
    @JavascriptInterface
    public boolean launch(String json) {
        try {
            JSONArray a = new JSONArray(json);
            PackageManager pm = ctx.getPackageManager();
            for (int k = 0; k < a.length(); k++) {
                JSONObject o = a.getJSONObject(k);
                String p = o.optString("p");
                String c = o.optString("c");
                String l = o.optString("l");
                if (p.length() > 0 && c.length() > 0) {
                    Intent i = new Intent(Intent.ACTION_MAIN);
                    i.setComponent(new ComponentName(p, c));
                    if (start(i)) {
                        return true;
                    }
                }
                if (p.length() > 0) {
                    Intent i = pm.getLaunchIntentForPackage(p);
                    if (i != null && start(i)) {
                        return true;
                    }
                }
                if (l.length() > 0) {
                    String pk = findByLabel(l);
                    if (pk != null) {
                        Intent i = pm.getLaunchIntentForPackage(pk);
                        if (i != null && start(i)) {
                            return true;
                        }
                    }
                }
            }
        } catch (Exception e) {
            // fall through
        }
        return false;
    }

    @JavascriptInterface
    public String getApps() {
        String c = appsCache;
        if (c != null) {
            refreshApps();
            return c;
        }
        String r = buildApps();
        appsCache = r;
        return r;
    }

    private String buildApps() {
        try {
            PackageManager pm = ctx.getPackageManager();
            List<String[]> r = new ArrayList<String[]>();
            for (ResolveInfo ri : apps()) {
                String pk = ri.activityInfo.packageName;
                if (pk.equals(ctx.getPackageName())) {
                    continue;
                }
                r.add(new String[]{String.valueOf(ri.loadLabel(pm)), pk, ri.activityInfo.name});
            }
            Collections.sort(r, new Comparator<String[]>() {
                @Override
                public int compare(String[] x, String[] y) {
                    return x[0].compareToIgnoreCase(y[0]);
                }
            });
            java.util.HashSet<String> have = new java.util.HashSet<String>();
            for (String[] s : r) {
                have.add(s[1]);
            }
            for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
                if (ai.packageName.equals(ctx.getPackageName()) || have.contains(ai.packageName)) {
                    continue;
                }
                Intent li = pm.getLaunchIntentForPackage(ai.packageName);
                if (li != null && li.getComponent() != null) {
                    r.add(new String[]{String.valueOf(pm.getApplicationLabel(ai)), ai.packageName, li.getComponent().getClassName()});
                }
            }
            Collections.sort(r, new Comparator<String[]>() {
                @Override
                public int compare(String[] x, String[] y) {
                    return x[0].compareToIgnoreCase(y[0]);
                }
            });
            JSONArray out = new JSONArray();
            for (String[] s : r) {
                JSONObject o = new JSONObject();
                o.put("n", s[0]);
                o.put("p", s[1]);
                o.put("c", s[2]);
                out.put(o);
            }
            return out.toString();
        } catch (Exception e) {
            return "[]";
        }
    }

    @JavascriptInterface
    public String getIcon(String pkg) {
        try {
            Drawable d = ctx.getPackageManager().getApplicationIcon(pkg);
            int s = 96;
            Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            d.setBounds(0, 0, s, s);
            d.draw(cv);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.PNG, 100, bo);
            return "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
        } catch (Throwable e) {
            return "";
        }
    }

    @JavascriptInterface
    public String status() {
        boolean bt = false;
        boolean wf = false;
        try {
            bt = Settings.Global.getInt(ctx.getContentResolver(), "bluetooth_on", 0) == 1;
        } catch (Throwable e) {
            // ignore
        }
        try {
            WifiManager w = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            wf = w != null && w.isWifiEnabled();
        } catch (Throwable e) {
            // ignore
        }
        return "{\"bt\":" + bt + ",\"wifi\":" + wf + "}";
    }

    private MediaController controller() {
        MediaSessionManager m = (MediaSessionManager) ctx.getSystemService(Context.MEDIA_SESSION_SERVICE);
        List<MediaController> l = m.getActiveSessions(new ComponentName(ctx, MediaListener.class));
        MediaController best = null;
        for (MediaController c : l) {
            PlaybackState s = c.getPlaybackState();
            if (s != null && s.getState() == PlaybackState.STATE_PLAYING) {
                return c;
            }
            if (best == null) {
                best = c;
            }
        }
        return best;
    }

    private static String nz(String x) {
        return x == null ? "" : x;
    }

    @JavascriptInterface
    public String media() {
        try {
            MediaController c = controller();
            if (c == null) {
                return "{\"ok\":true,\"has\":false}";
            }
            MediaMetadata md = c.getMetadata();
            PlaybackState ps = c.getPlaybackState();
            JSONObject o = new JSONObject();
            o.put("ok", true);
            o.put("has", true);
            o.put("title", md == null ? "" : nz(md.getString(MediaMetadata.METADATA_KEY_TITLE)));
            o.put("artist", md == null ? "" : nz(md.getString(MediaMetadata.METADATA_KEY_ARTIST)));
            o.put("dur", md == null ? 0 : md.getLong(MediaMetadata.METADATA_KEY_DURATION));
            o.put("pos", ps == null ? 0 : ps.getPosition());
            o.put("playing", ps != null && ps.getState() == PlaybackState.STATE_PLAYING);
            return o.toString();
        } catch (SecurityException e) {
            return "{\"ok\":false,\"perm\":true}";
        } catch (Exception e) {
            return "{\"ok\":false}";
        }
    }

    @JavascriptInterface
    public boolean mediaCmd(String cmd) {
        try {
            MediaController c = controller();
            if (c == null) {
                return false;
            }
            if (cmd.equals("next")) {
                c.getTransportControls().skipToNext();
            } else if (cmd.equals("prev")) {
                c.getTransportControls().skipToPrevious();
            } else if (cmd.equals("play")) {
                c.getTransportControls().play();
            } else if (cmd.equals("pause")) {
                c.getTransportControls().pause();
            } else {
                PlaybackState s = c.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) {
                    c.getTransportControls().pause();
                } else {
                    c.getTransportControls().play();
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public String art() {
        try {
            MediaController c = controller();
            if (c == null) {
                return "";
            }
            MediaMetadata md = c.getMetadata();
            if (md == null) {
                return "";
            }
            Bitmap b = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
            if (b == null) {
                b = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
            }
            if (b == null) {
                return "";
            }
            Bitmap sm = Bitmap.createScaledBitmap(b, 128, 128, true);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            sm.compress(Bitmap.CompressFormat.JPEG, 80, bo);
            return "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
        } catch (Throwable e) {
            return "";
        }
    }

    @JavascriptInterface
    public void openNotifAccess() {
        start(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
    }

    @JavascriptInterface
    public boolean getAuto() {
        return ctx.getSharedPreferences("mz", Context.MODE_PRIVATE).getBoolean("auto", true);
    }

    @JavascriptInterface
    public void setAuto(boolean on) {
        ctx.getSharedPreferences("mz", Context.MODE_PRIVATE).edit().putBoolean("auto", on).apply();
        Intent s = new Intent(ctx, KeepAliveService.class);
        try {
            if (on) {
                if (Build.VERSION.SDK_INT >= 26) {
                    ctx.startForegroundService(s);
                } else {
                    ctx.startService(s);
                }
            } else {
                ctx.stopService(s);
            }
        } catch (Exception e) {
            // ignore
        }
    }

    @JavascriptInterface
    public boolean hasOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx);
    }

    @JavascriptInterface
    public void openOverlay() {
        start(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.getPackageName())));
    }

    @JavascriptInterface
    public String autoStart() {
        boolean ov = false;
        try {
            ov = Settings.canDrawOverlays(ctx);
        } catch (Throwable e) {
            // ignore
        }
        return "{\"overlay\":" + ov + "}";
    }

    /** Opens the "display over other apps" page first; once granted, asks to ignore battery optimisation. */
    @JavascriptInterface
    public void openAutoStart() {
        try {
            Uri u = Uri.parse("package:" + ctx.getPackageName());
            if (!Settings.canDrawOverlays(ctx)) {
                start(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, u));
            } else {
                start(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, u));
            }
        } catch (Throwable e) {
            // ignore
        }
    }

    @JavascriptInterface
    public String getLog() {
        return ctx.getSharedPreferences("mz", Context.MODE_PRIVATE).getString("log", "(empty)");
    }

    private boolean hasLocation() {
        return Build.VERSION.SDK_INT < 23
                || ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @JavascriptInterface
    public String getSpeed() {
        boolean perm = hasLocation();
        if (perm) {
            Gps.start(ctx);
        }
        long age = System.currentTimeMillis() - Gps.at;
        boolean fix = perm && Gps.at != 0 && age < 5000;
        return "{\"perm\":" + perm + ",\"fix\":" + fix + ",\"kmh\":" + Math.round(fix ? Gps.kmh : 0f) + "}";
    }

    @JavascriptInterface
    public void askLocation() {
        if (ctx instanceof Activity) {
            final Activity a = (Activity) ctx;
            a.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= 23) {
                        a.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 21);
                    }
                }
            });
        }
    }

    @JavascriptInterface
    public void openAppSettings() {
        start(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.getPackageName())));
    }

    @JavascriptInterface
    public boolean getAutoplay() {
        return ctx.getSharedPreferences("mz", Context.MODE_PRIVATE).getBoolean("autoplay", true);
    }

    @JavascriptInterface
    public void setAutoplay(boolean on) {
        ctx.getSharedPreferences("mz", Context.MODE_PRIVATE).edit().putBoolean("autoplay", on).apply();
    }

    @JavascriptInterface
    public String getLastMusic() {
        return ctx.getSharedPreferences("mz", Context.MODE_PRIVATE).getString("lastpkg", "");
    }
}
