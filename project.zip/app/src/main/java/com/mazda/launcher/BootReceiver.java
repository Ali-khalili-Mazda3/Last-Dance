package com.mazda.launcher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** After the head unit boots (or the app is updated): start the keep-alive service and show the launcher. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!c.getSharedPreferences("mz", Context.MODE_PRIVATE).getBoolean("auto", true)) {
            return;
        }
        KeepAliveService.start(c);
        KeepAliveService.showLauncher(c);
    }
}
