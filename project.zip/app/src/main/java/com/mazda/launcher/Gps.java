package com.mazda.launcher;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;

/** Reads the car speed from GPS (m/s converted to km/h). */
class Gps implements LocationListener {
    static volatile float kmh = 0;
    static volatile long at = 0;
    private static boolean started = false;
    private Location prev = null;

    static synchronized void start(Context c) {
        if (started) {
            return;
        }
        try {
            LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) {
                return;
            }
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, new Gps(), Looper.getMainLooper());
            started = true;
        } catch (SecurityException e) {
            // permission not granted yet
        } catch (Exception e) {
            // no GPS provider
        }
    }

    @Override
    public void onLocationChanged(Location l) {
        float v;
        if (l.hasSpeed()) {
            v = l.getSpeed() * 3.6f;
        } else if (prev != null && l.getTime() > prev.getTime()) {
            v = prev.distanceTo(l) / ((l.getTime() - prev.getTime()) / 1000f) * 3.6f;
        } else {
            v = 0;
        }
        prev = l;
        kmh = v < 2f ? 0f : v;
        at = System.currentTimeMillis();
    }

    @Override
    public void onStatusChanged(String p, int s, Bundle b) {
    }

    @Override
    public void onProviderEnabled(String p) {
    }

    @Override
    public void onProviderDisabled(String p) {
    }
}
