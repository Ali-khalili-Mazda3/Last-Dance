package com.mazda.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;

/** Reads speed, heading and trip data from GPS. */
class Gps implements LocationListener {
    static volatile float kmh = 0;
    static volatile long at = 0;
    static volatile int heading = -1;
    static volatile float tripM = 0;
    static volatile float maxKmh = 0;
    static volatile double lat = 0;
    static volatile double lon = 0;
    private static boolean started = false;
    private static Context app;
    private Location prev = null;
    private int count = 0;

    static synchronized void start(Context c) {
        if (started) {
            return;
        }
        try {
            app = c.getApplicationContext();
            SharedPreferences p = app.getSharedPreferences("mz", Context.MODE_PRIVATE);
            tripM = p.getFloat("trip_m", 0f);
            maxKmh = p.getFloat("max_kmh", 0f);
            lat = p.getFloat("lat", 0f);
            lon = p.getFloat("lon", 0f);
            LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) {
                return;
            }
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, new Gps(), Looper.getMainLooper());
            started = true;
        } catch (SecurityException e) {
            // permission not granted yet
        } catch (Exception e) {
            // no GPS provider
        }
    }

    static void reset(Context c) {
        tripM = 0;
        maxKmh = 0;
        save(c);
    }

    private static void save(Context c) {
        try {
            c.getApplicationContext().getSharedPreferences("mz", Context.MODE_PRIVATE).edit()
                    .putFloat("trip_m", tripM).putFloat("max_kmh", maxKmh)
                    .putFloat("lat", (float) lat).putFloat("lon", (float) lon).apply();
        } catch (Exception e) {
            // ignore
        }
    }

    @Override
    public void onLocationChanged(Location l) {
        float v;
        if (l.hasSpeed()) {
            v = l.getSpeed() * 3.6f;
        } else if (prev != null && l.getTime() > prev.getTime()) {
            v = prev.distanceTo(l) / ((l.getTime() - prev.getTime()) / 1000f) * 3.6f;
        } else {
            v = 0;
        }
        if (v >= 3f) {
            if (l.hasBearing()) {
                heading = Math.round(l.getBearing());
            }
            if (prev != null) {
                float dt = (l.getTime() - prev.getTime()) / 1000f;
                if (dt > 0 && dt < 10) {
                    tripM += prev.distanceTo(l);
                }
            }
            if (v > maxKmh && v < 300f) {
                maxKmh = v;
            }
        }
        prev = l;
        lat = l.getLatitude();
        lon = l.getLongitude();
        kmh = v < 2f ? 0f : v;
        at = System.currentTimeMillis();
        count++;
        if ((count == 1 || count % 15 == 0) && app != null) {
            save(app);
        }
    }

    @Override
    public void onStatusChanged(String p, int s, Bundle b) {
    }

    @Override
    public void onProviderEnabled(String p) {
    }

    @Override
    public void onProviderDisabled(String p) {
    }
}
