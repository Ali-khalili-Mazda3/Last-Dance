package com.mazda.launcher;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;

/**
 * Keeps a tiny foreground service alive. When the screen comes back after being off for a while
 * (ignition off/on), it brings the launcher to the front so Home does not have to be pressed.
 */
public class KeepAliveService extends Service {
    private static final long MIN_OFF_MS = 20000;
    private long offAt = 0;

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(a)) {
                offAt = System.currentTimeMillis();
            } else if (Intent.ACTION_SCREEN_ON.equals(a) || Intent.ACTION_USER_PRESENT.equals(a)) {
                long off = offAt == 0 ? 0 : System.currentTimeMillis() - offAt;
                if (off >= MIN_OFF_MS) {
                    offAt = 0;
                    showLauncher(c);
                }
            }
        }
    };

    static void showLauncher(Context c) {
        try {
            Intent i = new Intent(c, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            c.startActivity(i);
        } catch (Exception e) {
            // ignore
        }
    }

    static void start(Context c) {
        try {
            Intent s = new Intent(c, KeepAliveService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                c.startForegroundService(s);
            } else {
                c.startService(s);
            }
        } catch (Exception e) {
            // ignore
        }
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_USER_PRESENT);
        registerReceiver(rx, f);
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        try {
            startForeground(7, buildNotification());
        } catch (Exception e) {
            // ignore
        }
        return START_STICKY;
    }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("keep", "Launcher", NotificationManager.IMPORTANCE_MIN));
            return new Notification.Builder(this, "keep")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .setContentTitle("Mazda Launcher")
                    .build();
        }
        return new Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle("Mazda Launcher")
                .build();
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(rx);
        } catch (Exception e) {
            // ignore
        }
        super.onDestroy();
    }
}
