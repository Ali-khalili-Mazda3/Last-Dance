package com.mazda.launcher;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.view.KeyEvent;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Keeps a tiny foreground service alive. When the head unit wakes up (screen on, power connected,
 * or the clock shows the device was suspended), it brings the launcher to the front.
 */
public class KeepAliveService extends Service {
    private static final long MIN_OFF_MS = 20000;
    private static final long SLEEP_GAP_MS = 10000;
    private final Handler h = new Handler(Looper.getMainLooper());
    private long offAt = 0;
    private long lastSlept = 0;

    private final Runnable showAgain = new Runnable() {
        @Override
        public void run() {
            showLauncher(KeepAliveService.this);
        }
    };

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            long slept = SystemClock.elapsedRealtime() - SystemClock.uptimeMillis();
            if (lastSlept != 0 && slept - lastSlept > SLEEP_GAP_MS) {
                log(KeepAliveService.this, "woke from sleep (" + ((slept - lastSlept) / 1000) + "s)");
                wake();
            }
            lastSlept = slept;
            trackMedia();
            h.postDelayed(this, 2000);
        }
    };

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            log(c, "event " + a);
            if (Intent.ACTION_SCREEN_OFF.equals(a)) {
                offAt = System.currentTimeMillis();
            } else {
                long off = offAt == 0 ? MIN_OFF_MS : System.currentTimeMillis() - offAt;
                if (off >= MIN_OFF_MS) {
                    offAt = 0;
                    wake();
                }
            }
        }
    };

    private boolean auto() {
        return getSharedPreferences("mz", Context.MODE_PRIVATE).getBoolean("auto", true);
    }

    /** Show the launcher now, and again a little later in case the system re-opens another app. */
    private void wake() {
        if (autoplay()) {
            h.removeCallbacks(resume);
            h.postDelayed(resume, 6000);
        }
        if (!auto()) {
            return;
        }
        showLauncher(this);
        h.removeCallbacks(showAgain);
        h.postDelayed(showAgain, 2000);
        h.postDelayed(showAgain, 5000);
    }

    private final Runnable resume = new Runnable() {
        @Override
        public void run() {
            resumeMusic();
        }
    };

    private final Runnable resumeRetry = new Runnable() {
        @Override
        public void run() {
            resumeRetryStep();
        }
    };

    private boolean autoplay() {
        return getSharedPreferences("mz", Context.MODE_PRIVATE).getBoolean("autoplay", true);
    }

    private List<MediaController> sessions() {
        MediaSessionManager m = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
        return m.getActiveSessions(new ComponentName(this, MediaListener.class));
    }

    /** Remember the package of the player that is playing right now. */
    private void trackMedia() {
        try {
            for (MediaController c : sessions()) {
                PlaybackState st = c.getPlaybackState();
                if (st != null && st.getState() == PlaybackState.STATE_PLAYING) {
                    String old = getSharedPreferences("mz", Context.MODE_PRIVATE).getString("lastpkg", "");
                    if (!c.getPackageName().equals(old)) {
                        getSharedPreferences("mz", Context.MODE_PRIVATE).edit().putString("lastpkg", c.getPackageName()).apply();
                    }
                    return;
                }
            }
        } catch (Exception e) {
            // no notification access yet
        }
    }

    private MediaController pickController() {
        String last = getSharedPreferences("mz", Context.MODE_PRIVATE).getString("lastpkg", "");
        MediaController first = null;
        for (MediaController c : sessions()) {
            if (last.length() > 0 && last.equals(c.getPackageName())) {
                return c;
            }
            if (first == null) {
                first = c;
            }
        }
        return first;
    }

    private boolean playController() {
        try {
            MediaController c = pickController();
            if (c == null) {
                return false;
            }
            PlaybackState st = c.getPlaybackState();
            if (st != null && st.getState() == PlaybackState.STATE_PLAYING) {
                log(this, "music already playing");
                return true;
            }
            c.getTransportControls().play();
            log(this, "play sent to " + c.getPackageName());
            return true;
        } catch (SecurityException e) {
            log(this, "music: allow notification access");
        } catch (Exception e) {
            log(this, "music error");
        }
        return false;
    }

    /** Press the "play" media key; Android hands it to the player that was used last. */
    private void sendPlayKey() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            long t = SystemClock.uptimeMillis();
            am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY, 0));
            am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY, 0));
            log(this, "play key sent");
        } catch (Exception e) {
            log(this, "play key failed");
        }
    }

    private void resumeMusic() {
        if (!autoplay()) {
            return;
        }
        if (playController()) {
            return;
        }
        sendPlayKey();
        h.removeCallbacks(resumeRetry);
        h.postDelayed(resumeRetry, 4000);
    }

    /** If nothing is playing yet, open the last player once, press play, and come back to the launcher. */
    private void resumeRetryStep() {
        if (playController()) {
            return;
        }
        String last = getSharedPreferences("mz", Context.MODE_PRIVATE).getString("lastpkg", "");
        if (last.length() == 0) {
            log(this, "no last player known yet");
            return;
        }
        try {
            Intent li = getPackageManager().getLaunchIntentForPackage(last);
            if (li != null) {
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(li);
                log(this, "opened " + last);
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        playController();
                        showLauncher(KeepAliveService.this);
                    }
                }, 5000);
            }
        } catch (Exception e) {
            log(this, "could not open " + last);
        }
    }

    static void log(Context c, String m) {
        try {
            SharedPreferences p = c.getSharedPreferences("mz", Context.MODE_PRIVATE);
            String old = p.getString("log", "");
            String line = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(new Date()) + " " + m;
            String[] ls = old.length() == 0 ? new String[0] : old.split("\n");
            StringBuilder sb = new StringBuilder(line);
            for (int k = 0; k < ls.length && k < 11; k++) {
                sb.append('\n').append(ls[k]);
            }
            p.edit().putString("log", sb.toString()).apply();
        } catch (Exception e) {
            // ignore
        }
    }

    static void showLauncher(Context c) {
        try {
            Intent i = new Intent(c, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            c.startActivity(i);
            log(c, "show launcher");
        } catch (Exception e) {
            log(c, "show launcher failed");
        }
    }

    static void start(Context c) {
        start(c, false);
    }

    static void start(Context c, boolean boot) {
        try {
            Intent s = new Intent(c, KeepAliveService.class);
            s.putExtra("boot", boot);
            if (Build.VERSION.SDK_INT >= 26) {
                c.startForegroundService(s);
            } else {
                c.startService(s);
            }
        } catch (Exception e) {
            // ignore
        }
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        IntentFilter f = new IntentFilter();
        String[] acts = new String[]{
                Intent.ACTION_SCREEN_OFF,
                Intent.ACTION_SCREEN_ON,
                Intent.ACTION_USER_PRESENT,
                Intent.ACTION_POWER_CONNECTED,
                "android.intent.action.ACC_ON",
                "android.intent.action.ACC_BOOT",
                "com.android.action.ACC_ON"
        };
        for (String a : acts) {
            f.addAction(a);
        }
        registerReceiver(rx, f);
        lastSlept = SystemClock.elapsedRealtime() - SystemClock.uptimeMillis();
        h.postDelayed(tick, 2000);
        log(this, "service started");
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        if (i != null && i.getBooleanExtra("boot", false) && autoplay()) {
            h.removeCallbacks(resume);
            h.postDelayed(resume, 12000);
        }
        try {
            startForeground(7, buildNotification());
        } catch (Exception e) {
            // ignore
        }
        return START_STICKY;
    }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("keep", "Launcher", NotificationManager.IMPORTANCE_MIN));
            return new Notification.Builder(this, "keep")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .setContentTitle("Mazda Launcher")
                    .build();
        }
        return new Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle("Mazda Launcher")
                .build();
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        try {
            unregisterReceiver(rx);
        } catch (Exception e) {
            // ignore
        }
        super.onDestroy();
    }
}
